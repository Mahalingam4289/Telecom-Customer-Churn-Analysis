import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt
import os

print("=" * 60)
print("TELECOM CUSTOMER CHURN ANALYSIS")
print("LEVEL 13 - MODEL EXPLAINABILITY (SHAP)")
print("=" * 60)

# Dataset Path
dataset_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\ml_telco_churn.csv"

# Model Path
model_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\random_forest.pkl"

# Output Folder
output_folder = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\reports\shap_outputs"

os.makedirs(output_folder, exist_ok=True)

# Load Dataset
df = pd.read_csv(dataset_path)

print("\nDataset Loaded Successfully")
print(df.shape)

# Features
X = df.drop("churn_value", axis=1)

print("\nFeatures Shape:")
print(X.shape)

# ============================================================
# CONVERT BOOLEAN COLUMNS TO INTEGER
# ============================================================

bool_columns = X.select_dtypes(include=["bool"]).columns

X[bool_columns] = X[bool_columns].astype(int)

print("\nBoolean Columns Converted to Integer")
print("Total:", len(bool_columns))

print("\nData Types After Conversion:")
print(X.dtypes.value_counts())

# Load Model
model = joblib.load(model_path)

print("\nRandom Forest Model Loaded Successfully")

# ============================================================
# SAMPLE DATA
# ============================================================

print("\nCreating Sample Dataset...")

X_sample = X.sample(
    n=200,
    random_state=42
)

print("Sample Shape:")
print(X_sample.shape)

# ============================================================
# CREATE SHAP EXPLAINER
# ============================================================

print("\nCreating SHAP Explainer...")

print("\nCreating SHAP Tree Explainer...")

explainer = shap.TreeExplainer(model)

print("Tree Explainer Created Successfully")

print("\nCalculating SHAP Values...")

shap_values = explainer.shap_values(X_sample)

print("SHAP Values Generated Successfully")

# ============================================================
# CALCULATE SHAP VALUES
# ============================================================

print("\nCalculating SHAP Values...")

shap_values = explainer(X_sample)

print("SHAP Values Generated Successfully")

# ============================================================
# INFORMATION
# ============================================================

print("\nSHAP Information")

print("Records :", X_sample.shape[0])

print("Features:", X_sample.shape[1])

print("SHAP Values Shape:")

print(shap_values.values.shape)

# ============================================================
# SHAP SUMMARY PLOT
# ============================================================

print("\nCreating SHAP Summary Plot...")

plt.figure(figsize=(12,8))

shap.summary_plot(
    shap_values[:, :, 1],
    X_sample,
    show=False
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        output_folder,
        "shap_summary_plot.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("✓ shap_summary_plot.png Saved")

# ============================================================
# SHAP BAR PLOT
# ============================================================

print("\nCreating SHAP Feature Importance Plot...")

plt.figure(figsize=(10,8))

shap.plots.bar(
    shap_values[:, :, 1],
    show=False
)

plt.savefig(
    os.path.join(
        output_folder,
        "shap_bar_plot.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("✓ shap_bar_plot.png Saved")

# ============================================================
# SHAP WATERFALL PLOT
# ============================================================

print("\nCreating SHAP Waterfall Plot...")

plt.figure(figsize=(10,8))

shap.plots.waterfall(
    shap_values[0, :, 1],
    show=False
)

plt.savefig(
    os.path.join(
        output_folder,
        "shap_waterfall_plot.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("✓ shap_waterfall_plot.png Saved")

