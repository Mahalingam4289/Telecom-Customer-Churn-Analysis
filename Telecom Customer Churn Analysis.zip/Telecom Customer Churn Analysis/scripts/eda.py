import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ==========================
# Load Dataset
# ==========================

file_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\cleaned_telco_churn.csv"

df = pd.read_csv(file_path)

print("Dataset Loaded Successfully")
print("Shape:", df.shape)

# ==========================
# Create Output Folder
# ==========================

output_folder = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\reports\eda_images"

os.makedirs(output_folder, exist_ok=True)

# Better chart style
sns.set_style("whitegrid")

# ==========================
# 1. Churn Distribution
# ==========================

plt.figure(figsize=(6, 4))
sns.countplot(data=df, x="churn_label")
plt.title("Customer Churn Distribution")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "churn_distribution.png")
)
plt.close()

print("✓ churn_distribution.png created")

# ==========================
# 2. Contract vs Churn
# ==========================

plt.figure(figsize=(8, 5))
sns.countplot(
    data=df,
    x="contract",
    hue="churn_label"
)

plt.title("Contract Type vs Churn")
plt.xticks(rotation=15)
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "contract_vs_churn.png")
)
plt.close()

print("✓ contract_vs_churn.png created")

# ==========================
# 3. Internet Service vs Churn
# ==========================

plt.figure(figsize=(8, 5))
sns.countplot(
    data=df,
    x="internet_service",
    hue="churn_label"
)

plt.title("Internet Service vs Churn")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "internet_service_vs_churn.png")
)
plt.close()

print("✓ internet_service_vs_churn.png created")

# ==========================
# 4. Payment Method vs Churn
# ==========================

plt.figure(figsize=(10, 5))
sns.countplot(
    data=df,
    x="payment_method",
    hue="churn_label"
)

plt.xticks(rotation=30)
plt.title("Payment Method vs Churn")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "payment_method_vs_churn.png")
)
plt.close()

print("✓ payment_method_vs_churn.png created")

# ==========================
# 5. Senior Citizen vs Churn
# ==========================

plt.figure(figsize=(6, 4))
sns.countplot(
    data=df,
    x="senior_citizen",
    hue="churn_label"
)

plt.title("Senior Citizen vs Churn")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "senior_citizen_churn.png")
)
plt.close()

print("✓ senior_citizen_churn.png created")

# ==========================
# Convert Total Charges
# ==========================

df["total_charges"] = pd.to_numeric(
    df["total_charges"],
    errors="coerce"
)

# ==========================
# 6. Monthly Charges Analysis
# ==========================

plt.figure(figsize=(8, 5))
sns.boxplot(
    data=df,
    x="churn_label",
    y="monthly_charges"
)

plt.title("Monthly Charges vs Churn")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "monthly_charges_churn.png")
)
plt.close()

print("✓ monthly_charges_churn.png created")

# ==========================
# 7. Tenure Analysis
# ==========================

plt.figure(figsize=(8, 5))

sns.histplot(
    data=df,
    x="tenure_months",
    hue="churn_label",
    kde=True
)

plt.title("Tenure Distribution")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "tenure_distribution.png")
)
plt.close()

print("✓ tenure_distribution.png created")

print("\nEDA Completed Successfully!")