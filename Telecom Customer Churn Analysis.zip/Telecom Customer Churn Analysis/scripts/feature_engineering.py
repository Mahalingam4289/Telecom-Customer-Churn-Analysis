import pandas as pd

# Load Dataset
file_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\cleaned_telco_churn.csv"

df = pd.read_csv(file_path)

print("Dataset Loaded")
print(df.shape)

# Remove unwanted columns
drop_columns = [
    "customer_id",
    "count",
    "country",
    "state",
    "city",
    "zip_code",
    "lat_long",
    "latitude",
    "longitude",
    "churn_reason",
    "churn_label",
    "churn_score"
]

df = df.drop(columns=drop_columns)

print("\nColumns After Removal:")
print(df.shape)

# Convert total_charges
df["total_charges"] = pd.to_numeric(
    df["total_charges"],
    errors="coerce"
)

df["total_charges"] = df["total_charges"].fillna(
    df["total_charges"].median()
)

# STEP 5
print("\nTarget Variable Check:")
print(df["churn_value"].value_counts())

# STEP 6
df_encoded = pd.get_dummies(
    df,
    drop_first=True
)

print("\nEncoded Shape:")
print(df_encoded.shape)

# STEP 7
print("\nMissing Values:")
print(df_encoded.isnull().sum().sum())
print("\nColumns With Missing Values:")
print(
    df_encoded.isnull().sum()[
        df_encoded.isnull().sum() > 0
    ]
)

# STEP 8
output_file = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\ml_telco_churn.csv"

df_encoded.to_csv(
    output_file,
    index=False
)

print("\nML Dataset Saved Successfully")
print(output_file)