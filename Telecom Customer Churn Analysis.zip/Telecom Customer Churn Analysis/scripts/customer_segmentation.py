import pandas as pd
import matplotlib.pyplot as plt
import os

print("=" * 60)
print("LEVEL 14 - CUSTOMER SEGMENTATION")
print("=" * 60)

# ===================================================
# DATASET PATH
# ===================================================

dataset_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\ml_telco_churn.csv"

output_data = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\customer_segments.csv"

output_chart = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\reports\customer_segments"

os.makedirs(output_chart, exist_ok=True)

# ===================================================
# LOAD DATASET
# ===================================================

df = pd.read_csv(dataset_path)

print("\nDataset Loaded Successfully")

print(df.shape)

print("\nColumns")

print(df.columns.tolist())

print("\nMissing Values")

print(df.isnull().sum().sum())

# ===================================================
# CUSTOMER SEGMENTATION FUNCTION
# ===================================================

def customer_segment(row):

    # Churned Customer
    if row["churn_value"] == 1:
        return "At Risk"

    # High CLTV Customer
    elif row["cltv"] >= 5000:
        return "High Value"

    # Loyal Customer
    elif row["tenure_months"] >= 24:
        return "Loyal"

    # New Customer
    elif row["tenure_months"] < 6:
        return "New Customer"

    # Remaining Customers
    else:
        return "Regular"

# ===================================================
# APPLY SEGMENTATION
# ===================================================

df["customer_segment"] = df.apply(
    customer_segment,
    axis=1
)

print("\nCustomer Segmentation Completed")

print("\nCustomer Segment Counts")

print(df["customer_segment"].value_counts())

# ===================================================
# SAVE DATASET
# ===================================================

df.to_csv(
    output_data,
    index=False
)

print("\nCustomer Segmentation Dataset Saved Successfully")

print(output_data)