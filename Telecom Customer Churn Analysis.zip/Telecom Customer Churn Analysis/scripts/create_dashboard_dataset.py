import pandas as pd

print("=" * 60)
print("CREATE DASHBOARD DATASET")
print("=" * 60)

# Load cleaned dataset
cleaned = pd.read_csv(
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\cleaned_telco_churn.csv"
)

# Load customer segments
segments = pd.read_csv(
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\customer_segments.csv"
)

print("\nDatasets Loaded")

print(cleaned.shape)
print(segments.shape)

# Copy customer segment column
cleaned["customer_segment"] = segments["customer_segment"]

# Save dashboard dataset
output_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\dashboard_dataset.csv"

cleaned.to_csv(output_path, index=False)

print("\nDashboard Dataset Created Successfully")

print(cleaned.shape)

print("\nSaved To")

print(output_path)