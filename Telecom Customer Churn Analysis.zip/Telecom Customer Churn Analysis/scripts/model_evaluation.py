import pandas as pd

from sklearn.model_selection import train_test_split

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_auc_score
)

import joblib

file_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\ml_telco_churn.csv"

df = pd.read_csv(file_path)

print("Dataset Loaded")
print(df.shape)

X = df.drop("churn_value", axis=1)

y = df["churn_value"]

print("\nFeatures Shape:")
print(X.shape)

print("\nTarget Shape:")
print(y.shape)

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)

print("\nTesting Records:")
print(len(X_test))

log_model = joblib.load(
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\logistic_regression.pkl"
)

dt_model = joblib.load(
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\decision_tree.pkl"
)

rf_model = joblib.load(
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\random_forest.pkl"
)


print("\nModels Loaded Successfully")

log_pred = log_model.predict(X_test)

dt_pred = dt_model.predict(X_test)

rf_pred = rf_model.predict(X_test)

print("\nPredictions Generated")


log_acc = accuracy_score(y_test, log_pred)

dt_acc = accuracy_score(y_test, dt_pred)

rf_acc = accuracy_score(y_test, rf_pred)

print("\nModel Accuracy")
print("Logistic Regression:", round(log_acc * 100, 2), "%")
print("Decision Tree:", round(dt_acc * 100, 2), "%")
print("Random Forest:", round(rf_acc * 100, 2), "%")


print("\n" + "=" * 50)
print("LOGISTIC REGRESSION REPORT")
print("=" * 50)

print(
    classification_report(
        y_test,
        log_pred
    )
)

print("\n" + "=" * 50)
print("DECISION TREE REPORT")
print("=" * 50)

print(
    classification_report(
        y_test,
        dt_pred
    )
)

print("\n" + "=" * 50)
print("RANDOM FOREST REPORT")
print("=" * 50)

print(
    classification_report(
        y_test,
        rf_pred
    )
)


print("\n" + "=" * 50)
print("CONFUSION MATRIX")
print("=" * 50)

print("\nLogistic Regression")

print(
    confusion_matrix(
        y_test,
        log_pred
    )
)

print("\nDecision Tree")

print(
    confusion_matrix(
        y_test,
        dt_pred
    )
)

print("\nRandom Forest")

print(
    confusion_matrix(
        y_test,
        rf_pred
    )
)


log_auc = roc_auc_score(
    y_test,
    log_pred
)

dt_auc = roc_auc_score(
    y_test,
    dt_pred
)

rf_auc = roc_auc_score(
    y_test,
    rf_pred
)

print("\n" + "=" * 50)
print("ROC AUC SCORE")
print("=" * 50)

print(
    "Logistic Regression:",
    round(log_auc, 4)
)

print(
    "Decision Tree:",
    round(dt_auc, 4)
)

print(
    "Random Forest:",
    round(rf_auc, 4)
)


comparison = pd.DataFrame({
    "Model": [
        "Logistic Regression",
        "Decision Tree",
        "Random Forest"
    ],
    "Accuracy": [
        round(log_acc * 100, 2),
        round(dt_acc * 100, 2),
        round(rf_acc * 100, 2)
    ],
    "ROC_AUC": [
        round(log_auc, 4),
        round(dt_auc, 4),
        round(rf_auc, 4)
    ]
})

print("\n")
print(comparison)



