import pandas as pd

file_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\ml_telco_churn.csv"

df = pd.read_csv(file_path)

print("Dataset Loaded")
print(df.shape)

X = df.drop("churn_value", axis=1)

y = df["churn_value"]

print("\nFeatures Shape:")
print(X.shape)

print("\nTarget Shape:")
print(y.shape)

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)

print("\nTraining Data:")
print(X_train.shape)

print("\nTesting Data:")
print(X_test.shape)

from sklearn.linear_model import LogisticRegression

log_model = LogisticRegression(
    max_iter=1000
)

log_model.fit(
    X_train,
    y_train
)

print("\nLogistic Regression Trained")

from sklearn.tree import DecisionTreeClassifier

dt_model = DecisionTreeClassifier(
    random_state=42
)

dt_model.fit(
    X_train,
    y_train
)

print("Decision Tree Trained")

from sklearn.ensemble import RandomForestClassifier

rf_model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

rf_model.fit(
    X_train,
    y_train
)

print("Random Forest Trained")

print("\nTraining Accuracy")

print(
    "Logistic Regression:",
    round(
        log_model.score(X_train, y_train) * 100,
        2
    ),
    "%"
)

print(
    "Decision Tree:",
    round(
        dt_model.score(X_train, y_train) * 100,
        2
    ),
    "%"
)

print(
    "Random Forest:",
    round(
        rf_model.score(X_train, y_train) * 100,
        2
    ),
    "%"
)


import joblib

joblib.dump(
    log_model,
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\logistic_regression.pkl"
)

joblib.dump(
    dt_model,
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\decision_tree.pkl"
)

joblib.dump(
    rf_model,
    r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\models\trained_models\random_forest.pkl"
)

print("\nModels Saved Successfully")