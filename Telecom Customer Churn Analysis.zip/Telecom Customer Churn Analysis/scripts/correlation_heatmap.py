import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

file_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\cleaned_telco_churn.csv"

df = pd.read_csv(file_path)

df["total_charges"] = pd.to_numeric(
    df["total_charges"],
    errors="coerce"
)

numeric_df = df.select_dtypes(
    include=["int64", "float64"]
)

output_folder = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\reports\eda_images"

os.makedirs(output_folder, exist_ok=True)

plt.figure(figsize=(10, 8))

sns.heatmap(
    numeric_df.corr(),
    annot=True,
    fmt=".2f"
)

plt.title("Correlation Heatmap")
plt.tight_layout()

plt.savefig(
    os.path.join(output_folder, "correlation_heatmap.png")
)

plt.close()

print("✓ correlation_heatmap.png created")