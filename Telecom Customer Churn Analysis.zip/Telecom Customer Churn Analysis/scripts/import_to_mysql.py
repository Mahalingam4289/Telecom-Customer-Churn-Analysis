import pandas as pd
from sqlalchemy import create_engine

# Load cleaned dataset
file_path = r"C:\Users\MAHALINGAM R\PycharmProjects\Telecom Customer Churn Analysis\data\processed\cleaned_telco_churn.csv"

df = pd.read_csv(file_path)

# MySQL Connection
username = "root"
password = "0000"
host = "localhost"
database = "telecom_customer_churn"

engine = create_engine(
    f"mysql+pymysql://{username}:{password}@{host}/{database}"
)

# Import data
df.to_sql(
    name="telecom_customers",
    con=engine,
    if_exists="replace",
    index=False
)

print("Dataset Imported Successfully!")
print(f"Rows Imported: {len(df)}")
print(f"Columns Imported: {len(df.columns)}")